<div class="right_col" role="main">
    <div class="page-title">
        <div class="title_left">
            <h3>Imunisasi Anak</h3>
        </div>
    </div>
    <div class="flash-datar" data-flashdata="<?php echo $this->session->flashdata('msg'); ?>"></div>
    <?php if ($this->session->flashdata('msg')) : ?>

    <?php endif; ?>
    <div class="clearfix"></div>
    <div class="row">
        <div class="col-md-12 col-sm-12 ">
            <div class="x_panel">
                <div class="x_content">
                    <br />
                    <form id="imunisasi-form" name="imunisasi-form" class="form-horizontal form-label-left" action="<?php echo base_url('imunisasi_anak/submit'); ?>" method="POST" enctype="multipart/form-data">
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="username">Nama Anak
                            </label>
                            <div class="col-md-6 col-sm-6">
                                <div class="input-group">
                                    <input type="hidden" name="id_anak" id="id_anak" class="form-control" readonly>
                                    <input type="text" name="nama_anak" id="nama_anak" class="form-control" readonly>
                                    <span class="input-group-btn">
                                        <button id="pilihData" name="pilihData" type="button" class="btn btn-outline-warning" data-toggle="modal" data-target="#DataAnakModal">Pilih</button>
                                    </span>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align">Jenis Kelamin</label>
                            <div class="col-md-6 col-sm-6">
                                <div class="input-group">
                                    <input type="text" name="jenis_kelamin" id="jenis_kelamin" readonly="" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align">Tanggal Lahir
                            </label>
                            <div class="col-md-6 col-sm-6">
                                <div class="input-group">
                                    <input class="date-picker form-control" name="tgl_lahir" id="tgl_lahir" type="text" type="text" onfocus="this.type='date'" onmouseover="this.type='date'" onclick="this.type='date'" onblur="this.type='text'" onmouseout="timeFunctionLong(this)" readonly>
                                    <script>
                                        function timeFunctionLong(input) {
                                            setTimeout(function() {
                                                input.type = 'text';
                                            }, 60000);
                                        }
                                    </script>
                                </div>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Nama Ibu
                            </label>
                            <div class="col-md-6 col-sm-6">
                                <div class="input-group">
                                    <input type="hidden" name="ibu_id" id="ibu_id" class="form-control" readonly>
                                    <input type="text" name="nama_ibu" id="nama_ibu" class="form-control" readonly>
                                </div>
                            </div>
                        </div>

                        <div class="divider-dashed"></div>
                        <h2>Imunisasi</h2>
                        <div class="divider-dashed"></div>

                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align">Tanggal Sekarang
                            </label>
                            <div class="col-md-6 col-sm-6">
                                <input class="date-picker form-control" name="tgl_skrng" id="tgl_skrng" type="text" type="text" onfocus="this.type='date'" onmouseover="this.type='date'" onclick="this.type='date'" onblur="this.type='text'" onmouseout="timeFunctionLong(this)">
                                <script>
                                    function timeFunctionLong(input) {
                                        setTimeout(function() {
                                            input.type = 'text';
                                        }, 60000);
                                    }
                                </script>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="usia">Usia
                            </label>
                            <div class="col-md-6 col-sm-6">
                                <input type=number step=any id="usia" name="usia" class="form-control">
                            </div>
                            <label class="col-form-label label-align" for="bulan">bulan
                            </label>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="imun">Imunisasi
                            </label>
                            <div class="col-md-6 col-sm-6">
																<select name="imun" id="" class="form-control">
																	<option value="">-- Pilih Imunisasi --</option>
																	<option value="BCG (Bacillus Calmette-Guérin):">BCG (Bacillus Calmette-Guérin):</option>
																	<option value="Hepatitis B">Hepatitis B</option>
																	<option value="DPT (Difteri, Pertusis, Tetanus)">DPT (Difteri, Pertusis, Tetanus)</option>
																	<option value="Polio">Polio</option>
																	<option value="Hib (Haemophilus influenzae tipe b)">Hib (Haemophilus influenzae tipe b)</option>
																	<option value="PCV (Pneumococcal Conjugate Vaccine)">PCV (Pneumococcal Conjugate Vaccine)</option>
																	<option value="Rotavirus">Rotavirus</option>
																	<option value="MR/MMR (Measles, Rubella / Measles, Mumps, Rubella)">MR/MMR (Measles, Rubella / Measles, Mumps, Rubella)</option>
																	<option value="Varicella">Varicella</option>
																	<option value="-">Lain lain</option>
																</select>
                                <input type=text id="" name="imun_custom" class="form-control" style="display:none;" placeholder="Input Manual" />
																<script>
																	$(document).ready(function() {
																		$('select[name="imun"]').change(function() {
																			if ($(this).val() == '-') {
																				$('input[name="imun_custom"]').show()
																			} else {
																				$('input[name="imun_custom"]').hide()
																			}
																		});
																	})
																</script>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align">Jenis Vitamin</label>
                            <div class="col-md-6 col-sm-6 ">
																<select name="vit[]" id="vit-select" class="form-control">
																		<option value="Vitamin A">Vitamin A</option>
																		<option value="Vitamin C">Vitamin C</option>
																		<option value="Vitamin D">Vitamin D</option>
																		<option value="Zat Besi">Zat Besi</option>
																		<option value="Yodium">Yodium</option>
																		<option value="-">Lain lain</option>
																</select>
                                <input type=text id="" name="vit_custom" class="form-control" style="display:none;" placeholder="Input Manual" />
																<script>
																	$(document).ready(function() {
																		$('#vit-select').change(function() {
																			if ($('#vit-select').val() == '-') {
																					$('input[name="vit_custom"]').show();
																			} else {
																					$('input[name="vit_custom"]').hide();
																			}
																		});
																	})
																</script>
                            </div>
                        </div>
                        <div class="form-group row">
                            <label class="col-form-label col-md-3 col-sm-3 label-align" for="name">Keterangan
                            </label>
                            <div class="col-md-6 col-sm-6">
                                <textarea id="keterangan" class="form-control" name="keterangan" data-parsley-trigger="keyup" data-parsley-minlength="20" data-parsley-maxlength="100" data-parsley-minlength-message="Come on! You need to enter at least a 20 caracters long comment.." data-parsley-validation-threshold="10"></textarea>
                            </div>
                        </div>
                        <div class="ln_solid"></div>
                        <div class="form-group row">
                            <div class="col-md-6 col-sm-6 offset-md-3">
                                <button type="submit" id="proses" name="proses" class="btn btn-success">Proses</button>
                            </div>
                        </div>
                    </form>

                    <!-- Modal Data Anak -->
                    <div class="modal fade bs-example-modal-lg" id="DataAnakModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog modal-lg" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Daftar Data Anak</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                                        <thead>
                                            <tr>
                                                <th>Nama Anak</th>
                                                <th>Jenis Kelamin</th>
                                                <th>Tanggal Lahir</th>
                                                <th>Nama Ibu</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php foreach ($d_anak as $d) : ?>
                                                <tr>
                                                    <td><?= $d['nama_anak']; ?></td>
                                                    <td><?= $d['jenis_kelamin']; ?></td>
                                                    <td><?= $d['tgl_lahir']; ?></td>
                                                    <td><?= $d['nama_ibu']; ?></td>
                                                    <td>
                                                        <button id="pilihAnak_Bidan" type="button" data-id="<?= $d['id_anak']; ?>" data-nama="<?= $d['nama_anak']; ?>" data-tgllahir="<?= $d['tgl_lahir']; ?>" data-idibu="<?= $d['ibu_id']; ?>" data-ibu="<?= $d['nama_ibu']; ?>" data-jk="<?= $d['jenis_kelamin']; ?>" class="btnSelectAnak btn btn-primary btn-sm">Pilih</button>
                                                    </td>
                                                </tr>
                                            <?php endforeach; ?>
                                        </tbody>
                                    </table>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
