<div class="col-md-3 left_col sidebar_fixed">
    <div class="left_col scroll-view">
        <div class="navbar nav_title" style="border: 0;">
            <a class="site_title"><img style="width: 29px; height: 29px; border-radius: 50%; margin-left: 10px" src="<?= base_url('build/img/'); ?>logo-posyandu-1.png" alt=""></i> <span>POSYANDU</span></a>
        </div>

        <div class="clearfix"></div>
        <br />
        <!-- sidebar menu -->
        <div id="sidebar-menu" class="main_menu_side hidden-print main_menu">
            <div class="menu_section">
                <h3>General</h3>
                <ul class="nav side-menu">
                    <li><a href="<?= base_url('dashboard/bidan') ?>"><i class="fa fa-home"></i> Dashboard</a>
                    </li>
                </ul>
            </div>
            <div class="menu_section">
                <h3>Layanan</h3>
                <ul class="nav side-menu">
                    <li><a href="<?= base_url('imunisasi_anak/imunisasi') ?>"><i class="fa fa-plus-square"></i> Imunisasi Anak</a>
                    </li>
                </ul>
                <ul class="nav side-menu">
                    <li><a href="<?= base_url('imunisasi_anak/data_imunisasi') ?>"><i class="fa fa-list"></i> Data Imunisasi</a>
                    </li>
                </ul>
            </div>
        </div>
        <!-- /sidebar menu -->
    </div>
</div>